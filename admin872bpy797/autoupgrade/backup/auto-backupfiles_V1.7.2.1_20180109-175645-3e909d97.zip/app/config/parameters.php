<?php return array (
  'parameters' => 
  array (
    'database_host' => '127.0.0.1',
    'database_port' => '',
    'database_name' => 'prestashop_db',
    'database_user' => 'prestashop_user',
    'database_password' => 'Michal123',
    'database_prefix' => 'ps_',
    'database_engine' => 'InnoDB',
    'mailer_transport' => 'smtp',
    'mailer_host' => '127.0.0.1',
    'mailer_user' => NULL,
    'mailer_password' => NULL,
    'secret' => 'cz8oSHbR2K4FHkjRADuIPFMBFxFWfjQ4tZvDY5EM5z5MGgKgLOhWMX3J',
    'ps_caching' => 'CacheMemcache',
    'ps_cache_enable' => false,
    'ps_creation_date' => '2017-11-05',
    'locale' => 'pl-PL',
    'cookie_key' => 'wcr0ujJJbWKaOtBAJ6tdmpZTzphHMbBhE3BfFABUMPAgAdkkwyYHDL71',
    'cookie_iv' => 'bv06Ccud',
    'new_cookie_key' => 'def0000031d10ee39b6073ca4e780c9b5323ecf32d02c4af7ffa2073584acc089c5c39f8800f5a198591d5e64f5a2bd713ee2a5f124feec4dcae12540f324ee1c7f8ae8f',
  ),
);